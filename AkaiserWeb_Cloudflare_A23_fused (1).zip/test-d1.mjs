// Runs the real Worker entry (src/worker.mjs) + D1Store against a SQLite database that behaves like D1 (Node's built-in node:sqlite). No network needed.
import { DatabaseSync } from 'node:sqlite';
import worker from './src/worker.mjs';
import { D1Store } from './src/d1store.mjs';

const sql = new DatabaseSync(':memory:');
const db = {   // the subset of the D1 API that d1store.mjs uses
  prepare(q) {
    const st = sql.prepare(q);
    const mk = (args) => ({
      async first() { return st.get(...args) ?? null; },
      async run() { const r = st.run(...args); return { meta: { changes: Number(r.changes) } }; },
    });
    return { ...mk([]), bind: (...a) => mk(a) };
  },
};
const assets = { fetch: async (req) => new Response('PAGE ' + new URL(req.url).pathname, { status: 200 }) };
const env = { DB: db, ASSETS: assets, MAX_DEVICES: '5', PBKDF2_ITERATIONS: '30000' };
let pass = 0, fail = 0;
const ok = (c, m) => { if (c) pass++; else { fail++; console.log('FAIL:', m); } };
const call = async (method, path, { body, cookie, device } = {}) => {
  const h = {};
  if (body !== undefined) h['content-type'] = 'application/json';
  if (cookie) h.cookie = cookie;
  if (device) h.authorization = 'Device ' + device;
  const res = await worker.fetch(new Request('https://akaiser.example.workers.dev' + path, { method, headers: h, body: body === undefined ? undefined : JSON.stringify(body) }), env, {});
  const text = await res.text();
  let json = null; try { json = JSON.parse(text); } catch { /* page */ }
  const sc = res.headers.get('set-cookie');
  return { status: res.status, json, text, cookie: sc ? sc.split(';')[0] : null, setCookie: sc };
};

let r = await call('GET', '/');                       ok(r.status === 200 && r.text === 'PAGE /', 'pages come from the assets');
r = await call('GET', '/api/ping');                   ok(r.status === 200 && r.json.ok, 'ping');
const DEV = 'd'.repeat(64);
r = await call('POST', '/api/device/status', { body: { name: 'Pixel' }, device: DEV });
ok(r.status === 200 && /^[A-Z2-9]{4}-[A-Z2-9]{4}$/.test(r.json.code), 'device gets a code');
const code = r.json.code;
r = await call('POST', '/api/signup', { body: { username: 'Bob', password: 'password1' } });
ok(r.status === 201 && /Secure/.test(r.setCookie) && /HttpOnly/.test(r.setCookie), 'sign up sets a Secure cookie');
const bob = r.cookie;
r = await call('POST', '/api/signup', { body: { username: 'bob', password: 'password1' } });
ok(r.status === 409, 'duplicate name refused (atomic insert)');
// two sign-ups at the same instant: exactly one wins
const both = await Promise.all([1, 2].map(() => call('POST', '/api/signup', { body: { username: 'Race', password: 'password1' } })));
ok(both.filter((x) => x.status === 201).length === 1 && both.filter((x) => x.status === 409).length === 1, 'same-moment double sign-up: one winner');
r = await call('POST', '/api/login', { body: { username: 'BOB', password: 'password1' } });   ok(r.status === 200, 'login');
r = await call('POST', '/api/login', { body: { username: 'bob', password: 'nope-nope' } });    ok(r.status === 401, 'wrong password');
r = await call('POST', '/api/link', { body: { code }, cookie: bob });                           ok(r.status === 200, 'link with the app code');
r = await call('POST', '/api/device/status', { body: {}, device: DEV });                       ok(r.json.linked === true && r.json.username === 'Bob', 'app sees it is linked');
r = await call('PUT', '/api/device/data', { body: { data: { a: 1 } }, device: DEV });           ok(r.status === 200, 'backup saved');
r = await call('GET', '/api/device/data', { device: DEV });                                    ok(r.json.data && r.json.data.a === 1, 'backup read');
const now = Date.now();
r = await call('POST', '/api/device/playtime', { body: { sessions: [{ id: 'sess-0001-abcd', seconds: 120, startedAt: now - 1000, game: 'Animal Kaiser' }] }, device: DEV });
ok(r.json.accepted === 1, 'play time accepted');
r = await call('POST', '/api/device/playtime', { body: { sessions: [{ id: 'sess-0001-abcd', seconds: 120, startedAt: now - 1000, game: 'Animal Kaiser' }] }, device: DEV });
ok(r.json.duplicate === 1 && r.json.totalSeconds === 120, 'resend not counted twice');
r = await call('POST', '/api/gacha', { cookie: bob });                                         ok(r.status === 200 && r.json.card, 'daily gacha');
const card = r.json.card.id;
r = await call('POST', '/api/gacha', { cookie: bob });                                         ok(r.status === 409, 'second gacha same day refused');
r = await call('POST', '/api/device/collection', { body: { cards: {} }, device: DEV });        ok(r.json.cards[card], 'gacha card reaches the app');
r = await call('GET', '/api/me', { cookie: bob });                                             ok(r.json.devices.length === 1 && r.json.playtime.totalSeconds === 120, '/api/me');
r = await call('POST', '/api/change-password', { body: { oldPassword: 'password1', newPassword: 'password2' }, cookie: bob });
ok(r.status === 200, 'password change'); const bob2 = r.cookie;
r = await call('POST', '/api/login', { body: { username: 'bob', password: 'password2' } });    ok(r.status === 200, 'login with new password');
r = await call('GET', '/api/nothing');                                                         ok(r.status === 404, 'unknown API -> 404');
r = await call('POST', '/api/delete-account', { body: { password: 'password2' }, cookie: bob2 });  ok(r.status === 200, 'account deleted');
r = await call('POST', '/api/device/status', { body: {}, device: DEV });                       ok(r.json.linked === false, 'device is unlinked after delete');

// the daily clean-up only removes expired throw-away keys
const store = new D1Store(db);
await store.setJSON('s:old', { lc: 'x', expires: 1 });
await store.setJSON('c:OLD', { h: 'x', exp: 1 });
await store.setJSON('u:keep', { username: 'keep' });
const n = await store.purge(Date.now());
ok(n >= 2 && (await store.get('s:old')) === null && (await store.get('c:OLD')) === null && (await store.get('u:keep')).username === 'keep', 'purge removes expired sessions/codes, keeps accounts');
// missing database binding gives a readable error instead of a crash
const noDb = await worker.fetch(new Request('https://x.test/api/ping'), { ASSETS: assets }, {});
ok(noDb.status === 500 && (await noDb.json()).error.includes('binding'), 'missing DB binding is explained');
console.log(`D1 checks: ${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
