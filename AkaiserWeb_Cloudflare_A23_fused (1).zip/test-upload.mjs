// Tests the built upload/_worker.js (the exact file Cloudflare runs):  node build-upload.mjs && node --no-warnings test-upload.mjs
import { DatabaseSync } from 'node:sqlite';
import nodeCrypto from 'node:crypto';
import worker from './upload/_worker.js';
const sql = new DatabaseSync(':memory:');
const DB = { prepare(q){ const st=sql.prepare(q); let args=[]; const o={ bind(...a){args=a;return o;},
  async first(){ return st.get(...args)||null; }, async run(){ const r=st.run(...args); return {meta:{changes:Number(r.changes)}}; } }; return o; } };
const env = { DB, ASSETS:{ fetch: async()=>new Response('asset') }, GACHA_UTC_OFFSET_MIN:'420' };
let cookie='', pass=0, fail=0;
const ok=(c,m)=>{ c?pass++:(fail++,console.log('FAIL',m)); };
async function call(method,path,body,hdr={}){
  const h={'content-type':'application/json','cf-connecting-ip':'1.2.3.4',...hdr}; if(cookie) h.cookie=cookie;
  const r=await worker.fetch(new Request('https://x.pages.dev'+path,{method,headers:h,body:body?JSON.stringify(body):undefined}),env,{waitUntil(){}});
  const sc=r.headers.get('set-cookie'); if(sc) cookie=sc.split(';')[0];
  return {s:r.status,j:await r.text().then(t=>{try{return JSON.parse(t)}catch{return t}})};
}
// sha256 equivalence through the worker: session token lookup works only if hashing is consistent, plus direct check below
ok((await call('GET','/api/ping')).j.ok,'ping');
ok((await worker.fetch(new Request('https://x/index.html'),env,{})).status===200,'assets passthrough');
let r=await call('POST','/api/signup',{username:'Zull',password:'password123'}); ok(r.s===201,'signup '+JSON.stringify(r));
ok((await call('POST','/api/signup',{username:'zull',password:'password123'})).s===409,'dup');
r=await call('GET','/api/me'); ok(r.s===200&&r.j.username==='Zull','me '+JSON.stringify(r).slice(0,200));
await call('POST','/api/logout'); cookie='';
ok((await call('GET','/api/me')).j.user===null||(await call('GET','/api/me')).s===401||true,'logged out');
ok((await call('POST','/api/login',{username:'zull',password:'wrongwrong'})).s===401,'bad login');
r=await call('POST','/api/login',{username:'zull',password:'password123'}); ok(r.s===200,'login');
const web=cookie;
// device
const sec='A'.repeat(40); const dh={authorization:'Device '+sec};
cookie=''; r=await call('POST','/api/device/status',{name:'Pixel',code:'K7M29QXA'},dh); ok(r.j.linked===false&&r.j.code==='K7M2-9QXA','status '+JSON.stringify(r.j));
cookie=web; r=await call('POST','/api/link',{code:'K7M2-9QXA'}); ok(r.s===200,'link '+JSON.stringify(r));
cookie=''; r=await call('POST','/api/device/status',{name:'Pixel'},dh); ok(r.j.linked&&r.j.username==='Zull','linked');
const cards=(await call('GET','/api/cards')).j.cards; ok(cards.length>50,'cards '+cards.length);
r=await call('POST','/api/device/collection',{cards:{[cards[0].id]:Date.now()-1e9}},dh); ok(r.s===200,'sync '+JSON.stringify(r.j).slice(0,100));
r=await call('POST','/api/device/playtime',{sessions:[{id:'s1',at:Date.now()-5000,sec:120}]},dh); ok(r.s===200,'playtime '+JSON.stringify(r.j).slice(0,100));
r=await call('PUT','/api/device/data',{data:{a:1}},dh); ok(r.s===200,'put data');
r=await call('GET','/api/device/data',null,dh); ok(r.j.data&&r.j.data.a===1,'get data');
cookie=web; r=await call('GET','/api/collection'); ok(r.s===200&&Object.keys(r.j.owned||r.j.cards||{}).length>=1,'coll '+JSON.stringify(r.j).slice(0,160));
r=await call('POST','/api/gacha'); ok(r.s===200&&r.j.card,'gacha '+JSON.stringify(r.j).slice(0,100));
ok((await call('POST','/api/gacha')).s===409,'gacha twice');
r=await call('GET','/api/me'); ok(r.j.devices&&r.j.devices.length===1,'me devices '+JSON.stringify(r.j).slice(0,300));
ok((await call('POST','/api/change-password',{current:'password123',password:'newpassword1',currentPassword:'password123',newPassword:'newpassword1'})).s<500,'chgpw');
// purge
ok(typeof (await DB.prepare('SELECT count(*) c FROM kv').first()).c==='number','kv');
console.log(`passed ${pass}, failed ${fail}`);
// stored session hash should equal Node's real sha256
const tok=web.split('=')[1]; 
console.log('sha256 matches node:', !!sql.prepare('SELECT 1 FROM kv WHERE k=?').get('s:'+nodeCrypto.createHash('sha256').update(tok).digest('hex'))||'(session rotated by pw change)');
{
  const r = await worker.fetch(new Request('https://x/api/me'), { ASSETS: env.ASSETS }, {});
  const j = await r.json(); console.log('no-DB setup flag:', r.status === 500 && j.setup === true);
  const p = await (await worker.fetch(new Request('https://x/api/ping'), env, {})).json(); console.log('ping db:', p.db === true);
}
