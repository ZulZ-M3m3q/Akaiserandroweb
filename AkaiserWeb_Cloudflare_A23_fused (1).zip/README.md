# AkaiserEvodroid account website - Cloudflare version

## FASTEST: drag-and-drop, no build (Cloudflare Pages)
The folder `upload/` is the finished site (pages + `_worker.js` API). Nothing to build or install.
1. Cloudflare -> **Workers & Pages** -> **Create** -> **Pages** -> **Upload assets** -> drag the `upload/` folder (or zip its contents) -> Deploy.
2. **Storage & databases -> D1** -> create a database (any name).
3. Your Pages project -> **Settings -> Bindings -> Add -> D1 database**: variable name exactly `DB`, pick the database. Save.
4. **Deployments -> Retry deployment** (bindings apply to new deployments). Open `https://YOUR-PROJECT.pages.dev/api/ping` -> `{"ok":true,"db":true}` (if the database is not connected yet, the site itself shows a short setup guide).
5. Build the APK with `web_url` = `https://YOUR-PROJECT.pages.dev` (no slash at the end).
Optional: Settings -> Variables: `GACHA_UTC_OFFSET_MIN` = `420` (daily card resets at midnight Jakarta time), `MAX_DEVICES`, `PBKDF2_ITERATIONS`.

After you change anything in `src/` or `public/`, run `node build-upload.mjs` (no install needed) to refresh `upload/`, then upload it again.

---
# Other way: Workers + wrangler (GitHub or PC)

Same website and same app API as the Netlify version. Runs on Cloudflare's free plan:
pages in `public/` (served by Cloudflare Workers Assets), the API in one Worker (`src/worker.mjs`), data in a D1 database.

## Deploy (GitHub method)
1. Create a GitHub repo and upload the CONTENTS of this folder (so `wrangler.jsonc` is in the repo root).
2. Cloudflare dashboard -> **Workers & Pages** -> **Create** -> **Import a repository** -> pick the repo.
   Leave the build command empty and the deploy command as `npx wrangler deploy`. Deploy.
   - **Database, option A (nothing to do):** the first deploy creates the D1 database `akaiser` and connects it as `DB`.
   - **Database, option B (if the deploy says it cannot create the database):** Storage & databases -> D1 -> Create database, name it `akaiser`,
     copy its ID, and add `"database_id": "THE-ID"` inside the `{ "binding": "DB", ... }` line of `wrangler.jsonc`, commit, deploy again.
   The table is created automatically on the first request (`schema.sql` is only there if you prefer to run it by hand).
3. Open the address Cloudflare gives you (`https://akaiser-accounts.YOUR-NAME.workers.dev`): you should see the sign-up page.
   The Worker name comes from `"name"` in `wrangler.jsonc`; change it there if you want another address.
4. Check the API (from a PC):
   `curl -i -X POST https://YOUR-SITE.workers.dev/api/device/status -H "Authorization: Device aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" -H "Content-Type: application/json" -d "{}"`
   It must answer `200` and `{"linked":false,"code":"XXXX-XXXX",...}`.
5. Build the APK (A.23 workflow) with `web_url` = `https://YOUR-SITE.workers.dev` (no slash at the end).

### Deploy from your PC instead
    npm install
    npx wrangler login
    npx wrangler deploy

## Test on your PC (no network, no Cloudflare account needed)
    node test.mjs        # 95 checks: the whole API against an in-memory store
    node --no-warnings test-d1.mjs     # 25 checks: the real Worker entry + D1 storage code on a SQLite database (needs Node 22+)
    node build-upload.mjs && node --no-warnings test-upload.mjs   # 22 checks on the built upload/_worker.js

## Settings (`vars` in `wrangler.jsonc`, then deploy again)
| name | default | meaning |
|---|---|---|
| `MAX_DEVICES` | 5 | phones one account may link |
| `GACHA_UTC_OFFSET_MIN` | 0 | daily gacha reset; `420` = midnight Jakarta time |
| `PBKDF2_ITERATIONS` | 30000 | password hashing cost (free plan limit: 10 ms CPU per request). Up to 100000 on a paid plan |

## Owner tools
Forgotten password: Cloudflare -> D1 -> `akaiser` -> Console, run
`DELETE FROM kv WHERE k = 'u:username_in_lowercase';` (the player can then sign up again with that name).
Look at a user: `SELECT v FROM kv WHERE k = 'u:username_in_lowercase';`

## What changed from the Netlify version
- Data: D1 table `kv` (key, JSON value, expiry) instead of Netlify Blobs. Same keys (`u:`, `s:`, `d:`, `c:`, `b:`, `p:`, `k:`, `g:`, `r:`).
  Old Netlify accounts are NOT moved: players sign up again on the new site (the app links to whichever site its `web_url` points to).
- Passwords use PBKDF2 (Web Crypto) instead of scrypt, because JS scrypt is too slow for the free plan's CPU limit.
- "Create only if new" is now a real atomic database insert, so two sign-ups for one name at the same instant can't both succeed.
- Security headers moved from `netlify.toml` to `public/_headers` (same values).
- A daily cron deletes expired sessions, link codes and rate-limit counters.
- Pages and API are on the same address, so cookies and the app work exactly as before.

## Free plan limits to know
Workers: 100,000 requests/day. D1: 100,000 writes and 5 million reads/day, 5 GB storage. A small group of players stays far below this.
