// Cloudflare Worker entry: /api/* is the account API (D1 = database); every other address is a page from public/ (served by Workers Assets).
import { createHandler } from './core.mjs';
import { D1Store } from './d1store.mjs';

let cached = null;
function setup(env) {
  if (!cached || cached.env !== env) {
    const store = new D1Store(env.DB);
    cached = {
      env, store,
      handle: createHandler(() => store, {
        maxDevices: parseInt(env.MAX_DEVICES || '5', 10),
        gachaOffsetMin: parseInt(env.GACHA_UTC_OFFSET_MIN || '0', 10),   // minutes; 420 = the daily gacha resets at midnight Jakarta time
        pbkdf2Iterations: parseInt(env.PBKDF2_ITERATIONS || '30000', 10),
      }),
    };
  }
  return cached;
}

export default {
  async fetch(req, env, ctx) {
    const url = new URL(req.url);
    if (!url.pathname.startsWith('/api/')) return env.ASSETS.fetch(req);
    if (!env.DB) {
      return new Response(JSON.stringify({ setup: true, db: false, error: 'Database not connected: the D1 binding "DB" is missing (see README step 2).' }),
        { status: 500, headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' } });
    }
    const s = setup(env);
    if (url.pathname === '/api/ping') {            // health check that also proves the database really answers
      try { await s.store.get('ping'); return new Response(JSON.stringify({ ok: true, service: 'akaiser-account', db: true }), { headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' } }); }
      catch (e) { console.error(e); return new Response(JSON.stringify({ ok: false, db: false, error: 'Database error: ' + String(e && e.message || e).slice(0, 200) }), { status: 500, headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' } }); }
    }
    if (ctx && ctx.waitUntil && Math.random() < 0.01) ctx.waitUntil(s.store.purge().catch(() => {}));   // clean-up of expired rows (also works on Pages, which has no cron)
    return s.handle(req, { ip: req.headers.get('cf-connecting-ip') || '' });
  },
  async scheduled(event, env) {
    if (env.DB) console.log('purged expired rows:', await setup(env).store.purge());
  },
};
