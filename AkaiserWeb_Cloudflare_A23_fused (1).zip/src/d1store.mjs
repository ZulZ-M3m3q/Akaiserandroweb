// Cloudflare D1 as the key-value store that core.mjs expects (the same 3 calls Netlify Blobs had).
// One table: kv(k, v = JSON text, exp = expiry in ms for the throw-away keys: rate limits r:, sessions s:, link codes c:).
const SCHEMA = 'CREATE TABLE IF NOT EXISTS kv (k TEXT PRIMARY KEY, v TEXT NOT NULL, exp INTEGER)';
const TEMP = /^[rsc]:/;

export class D1Store {
  constructor(db) {
    this.db = db;
    this.ready = null;
  }
  // The table is created by the first request, so no manual database setup step is needed (schema.sql does the same by hand).
  init() {
    return (this.ready ||= this.db.prepare(SCHEMA).run().catch((e) => { this.ready = null; throw e; }));
  }
  async get(k) {
    await this.init();
    const row = await this.db.prepare('SELECT v FROM kv WHERE k = ?').bind(k).first();
    return row ? JSON.parse(row.v) : null;
  }
  // opts.onlyIfNew: insert only when the key does not exist yet. Atomic in D1, so two simultaneous sign-ups for one name cannot both win.
  async setJSON(k, value, opts) {
    await this.init();
    const exp = TEMP.test(k) ? Number(value.exp ?? value.expires ?? value.reset) || null : null;
    const v = JSON.stringify(value);
    if (opts && opts.onlyIfNew) {
      const r = await this.db.prepare('INSERT INTO kv (k, v, exp) VALUES (?, ?, ?) ON CONFLICT(k) DO NOTHING').bind(k, v, exp).run();
      return { modified: r.meta.changes > 0 };
    }
    await this.db.prepare('INSERT INTO kv (k, v, exp) VALUES (?, ?, ?) ON CONFLICT(k) DO UPDATE SET v = excluded.v, exp = excluded.exp').bind(k, v, exp).run();
    return { modified: true };
  }
  async delete(k) {
    await this.init();
    await this.db.prepare('DELETE FROM kv WHERE k = ?').bind(k).run();
  }
  // Daily clean-up of expired sessions, link codes and rate-limit counters.
  async purge(t = Date.now()) {
    await this.init();
    const r = await this.db.prepare("DELETE FROM kv WHERE exp IS NOT NULL AND exp < ? AND (k LIKE 'r:%' OR k LIKE 's:%' OR k LIKE 'c:%')").bind(t).run();
    return r.meta.changes;
  }
}
