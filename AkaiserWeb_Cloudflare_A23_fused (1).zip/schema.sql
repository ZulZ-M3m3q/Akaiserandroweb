-- Optional. The Worker creates this table by itself on the first request; run this only if you prefer to do it by hand
-- (Cloudflare dashboard -> Storage & databases -> D1 -> akaiser -> Console).
CREATE TABLE IF NOT EXISTS kv (k TEXT PRIMARY KEY, v TEXT NOT NULL, exp INTEGER);
